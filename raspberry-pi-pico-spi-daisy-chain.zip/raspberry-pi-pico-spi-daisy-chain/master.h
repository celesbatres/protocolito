#ifndef MASTER_H
#define MASTER_H

#include "frame.h"

void master_init (void);
void master_propagate (struct frame *f);

#endif // !MASTER_H
