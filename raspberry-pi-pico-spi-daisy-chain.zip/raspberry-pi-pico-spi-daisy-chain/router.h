#ifndef ROUTER_H
#define ROUTER_H

void create_frame(char data[]);
#endif // !ROUTER_H
