#include <stdbool.h>

void ASSERT (bool expression);
